# VPS 信息流

不新增常驻业务进程：Hermes 每小时生成 JSON，现有 Nginx/Caddy 提供静态文件。抓取、摘要生成沿用你的 Hermes 配置。本目录负责验证、发布和定义客户端契约。

## 接入步骤

1. 给 Hermes 提供 `example-feed.json` 作为格式参考，修改为你的主题、来源和实际内容。条目 ID 使用来源 URL 或稳定标识；同一条内容更新时沿用 ID。建议每次输出最近一段时间的完整列表。
2. 输出到不公开的候选文件，例如 `/opt/little-check/candidate.json`。
3. Hermes 生成成功后执行：

```sh
python3 /opt/little-check/publish_feed.py /opt/little-check/candidate.json /var/www/little-check/feed.json
```

也支持标准输入：`python3 publish_feed.py - /var/www/little-check/feed.json`。

4. Nginx/Caddy 通过 HTTPS 提供 `feed.json`，App 设置里填写完整 URL。

已有 Hermes 调度功能时直接每小时执行现有任务；没有时使用 cron。下面只是一小时一次的**发布步骤**示例；必须放到抓取和生成成功后的流程里，不能把旧候选文件当作新结果反复发布：

```cron
0 * * * * flock -n /opt/little-check/job.lock /opt/little-check/hourly-job.sh >> /opt/little-check/hourly.log 2>&1
```

`hourly-job.sh` 应先执行你已经验证过的 Hermes 任务，再调用发布器。尚未提供实际 Hermes 命令，因此这里不猜测它的 CLI。任务整个执行链使用同一把锁；前一轮未结束时跳过这一轮，避免后完成的旧任务覆盖新结果。调度时区由 VPS 设置决定。

## JSON 契约

- `schema_version`: 整数 `1`。
- `generated_at`: 本次成功生成时间，带时区的 ISO8601，例如 `2026-10-02T08:00:00Z`。失败时保留原值。
- `items`: 最多 500 条，整个文件 UTF-8 大小最多 2 MiB。
- 每项 `id`、`title`、`summary`、`content`、`source`、`published_at` 必填字符串。ID 唯一、标题非空，正文使用 GFM Markdown。
- `url`: 可选 HTTP(S) 原始来源地址，不包含用户名密码。
- `tags`: 可选字符串数组。

更新失败：发布器退出码 `1`，错误写到 stderr，**原 feed.json 不变**。正常退出码 `0`。采用同目录临时文件、flush/fsync 和 `os.replace`，读者不会读到半截文件。App 通过内容生成时间识别旧内容，不伪造新的成功时间。

## Nginx 示例

把以下 location 合入你已有的 HTTPS server 块，保留你当前的证书、域名和其他路由配置：

```nginx
location = /feed.json {
    root /var/www/little-check;
    default_type application/json;
    charset utf-8;
    etag on;
    add_header Cache-Control "no-cache" always;
    try_files $uri =404;
}
```

App 使用 ETag/If-None-Match，304 时复用本地缓存；请求或内容校验失败时继续展示旧数据。初版网址内容是公开静态文件，只放允许通过该网址访问的内容，笔记不上传。

## 验证

```sh
python3 -m unittest discover -s server -v
```

本项目没有连接或修改你的 VPS。
