# 给 VPS agent 的任务

目标：为 Little Check 手机 App 接入静态信息流。VPS 为 2 核 2 GB，已有 Hermes。先检查现有网站服务和 Hermes 调度方式，复用已有能力。

## 内容偏好
由用户填写关注主题、来源和摘要长度，做成方便修改的配置。未提供时先询问，不自行订阅。

## 实现要求
1. Hermes 每小时生成一份候选 JSON，网站通过 HTTPS 提供 /feed.json。
2. 手机打开、回到前台或下拉时读取；不做锁屏推送、账号、数据库或额外常驻业务服务。Markdown 笔记和待办由手机本地管理。
3. 生成成功后调用 publish_feed.py，校验通过再原子替换公开文件。不要直接写网站上的 feed.json。
4. 抓取、生成或校验失败，保留上一份成功文件和原 generated_at，并记录错误。不要重复发布旧候选文件并伪造新时间。
5. JSON 参考 example-feed.json；完整接入与字段说明见 README.md。id 稳定且唯一，正文为 Markdown；最多 500 条、整个文件最多 2 MiB。
6. 优先使用 Hermes 已有调度，没有才使用 cron。执行链加锁，避免任务重叠。查证实际 Hermes 命令和输出格式，不猜测 CLI。
7. 沿用现有 Nginx/Caddy 和 HTTPS 配置，不覆盖其他网站、证书或环境配置。支持 ETag，Cache-Control 使用 no-cache。
8. feed.json 是公开网址，仅放用户允许公开的内容。

## 发布与测试
生成私有 candidate.json 后：
python3 publish_feed.py /实际路径/candidate.json /实际网站目录/feed.json

运行随包测试：
python3 -m unittest discover -s . -v

## 验收
- HTTPS 地址返回合法 JSON。
- 手动运行完整流程，内容更新成功。
- 用无效候选内容验证发布失败，公开文件字节不变。
- 每小时调度已配置，日志可定位失败。
- 最后提供完整 feed.json URL、内容配置位置、调度位置和手动执行命令。

用户将 URL 填入手机 App 设置中的“信息流地址”。本包尚未连接或修改 VPS。
